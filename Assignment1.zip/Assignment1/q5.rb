#!/Ruby24/bin/ruby

$, = ", "
h1 = { "1" => "Ajay", "2" => "Vijay" }
h2 = { "3" => "Daksh", "c" => "ABhi" }
h1.merge!(h2)   

puts h1