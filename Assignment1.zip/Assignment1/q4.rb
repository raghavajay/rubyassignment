#!/Ruby24/bin/ruby

$, = ", "
students= Hash.new( "stuent" )

students=  {"Ajay" => 78, "vijay" => "50", "daksh" => "100", "uma" => "90", "abhi" => "80"}

keys = students.keys
values=students.values

#Print each student�s grade as:
#Tim: 84
#George: 78

students.each {|key, value| puts "#{key} : #{value}" }

# Print only student names

students.each_key {|key| puts key }

# Print only grades

students.each_value {|value| puts value }

# Print only the name of student with highest grade
puts students.key("100")
# Delete 3rd student and his grades from the Hass
students.delete("daksh") 