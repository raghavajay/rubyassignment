#!/Ruby24/bin/ruby
 str="This is an assignment on Ruby Arrays"
str1=str.split(' ')
puts str1[(str1.size)-2]
puts str1[(str1.size)-1]