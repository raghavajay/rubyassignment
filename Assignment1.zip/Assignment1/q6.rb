#!/Ruby24/bin/ruby
class A

def addRecord( empID, name, cardNo, bloodGroup, photoName)

fname = "Emp.txt"
somefile = File.open(fname, "w")
somefile.puts empID+":"+name+":"+cardNo+":"+bloodGroup+":"+photoName
somefile.close
end

def changePhotoFileName(id, name)
file = File.open("Emp.txt", "w")
while !file.eof?
   line = file.readline
   if line.includes(id)
	newline=line.split(':')
file.puts newline[0]+":"+newline[1]+":"+newline[2]+":"+newline[3]+":"+name+".jpg"
  file.puts 
  file.close
end

end

obj=A.new
puts obj.addRecord("M1019315","Ajay Kumar","12345","AB+","jay.jpg")
puts obj.addRecord("M1019324","Vijay Kumar","12346","AB+","Vijay.jpg")
 
puts obj.changePhotoFileName("M1019315","Ajay Kumar")
