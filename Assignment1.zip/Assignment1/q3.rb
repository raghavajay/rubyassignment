#!/Ruby24/bin/ruby
arr1=[1,2,3]
arr2= [ 'Ajay','Vijay','daksh'] 
arr3=Array.new(3)
for i in 0..2 do
   arr3[i]="#{arr1[i]}"+"#{arr2[i]}"
end

puts "#{arr3}"