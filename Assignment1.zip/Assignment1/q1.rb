#!/Ruby24/bin/ruby

nums = Array.new(10) { |e| e = e*2 }

puts "#{nums}"