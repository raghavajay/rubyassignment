#!/Ruby24/bin/ruby

def find_type(char)

    if (/[[:lower:]]/.match(char))
        puts "A lower case letter,"
    elsif (/[[:upper:]]/.match(char))
        puts "A upper case letter,"
    elsif (/[[:digit:]]/.match(char))
        puts "A digit,"
    else
        puts "A special symbol"
    end
end
find_type('B')
find_type('a')
find_type('1')
find_type('$')