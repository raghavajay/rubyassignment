#!/Ruby24/bin/ruby

begin
  puts "Do you want to repeat that again?"
  answer = gets.chomp
end while answer == 'Y'

