#!/Ruby24/bin/ruby

require 'date'

 def age(dob)
     diff = Date.today - Date.parse(dob)
     age = (diff / 365.25).floor
     age.to_s
   end
puts "Enter the age of user in YYYY-MM-DD"
dob=gets
puts age(dob)


	