#!/Ruby24/bin/ruby

require 'date'
d = DateTime.now
#a. ANSI Format : yy/mm/dd
puts d.strftime("%y/%m/%d")
#b. British Format : dd-mm-yyyy 
puts d.strftime("%d-%m-%y")
#c. American Format : mm-dd-yy
puts d.strftime("%m-%d-%y")
#d. Long Format: DD-MMM-YYYY 
puts d.strftime("%d-%b-%Y")
#e. Character Day of the Week
puts d.strftime("%A")


