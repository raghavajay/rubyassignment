#!/Ruby24/bin/ruby

def sum_method(*p)
sum=0
for elt in p
sum= sum+elt
end
puts sum
end
# Printing when user is providing data
 sum_method(1,2,3,4,5,6)

# printing default values
 sum_method()

