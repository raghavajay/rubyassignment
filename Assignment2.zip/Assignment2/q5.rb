#!/Ruby24/bin/ruby

def printer(charProvided="*",count=40)
 i = 0
loop do
    i=i+1
    puts charProvided
  if i == count
    break       
  end
end
end
# Printing when user is providing data
printer("A",5)

# printing default values
printer()

