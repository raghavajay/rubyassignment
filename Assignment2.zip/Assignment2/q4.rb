#!/Ruby24/bin/ruby

def intrest_calculator(amount, noOfYrs, roi=10)
 intrest=amount*noOfYrs*roi/100
end
# Calculating Intrest when ROI is not defined
puts intrest_calculator(5000,1)

# Calculating Intrest when ROI is Provided by user
puts intrest_calculator(5000,1,15)

