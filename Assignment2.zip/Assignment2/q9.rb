#!/Ruby24/bin/ruby

 def sum_method(*p)
sum=0
for elt in p
sum= sum+elt
end
puts "%.2f" % [sum]
end
# Printing output to 2 decimal value when user is providing data to 4 decimal point
 sum_method(1.101,2.201,3.209,4.809,5.123,6.643)
	