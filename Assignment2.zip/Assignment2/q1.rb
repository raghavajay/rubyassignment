#!/Ruby24/bin/ruby

def message
puts "Welcome to BANGALORE"
puts "Have a nice day!"
end

message